<a name"0.4.1"></a>
### 0.4.1 (2015-09-01)


#### Bug Fixes

* **package.json:** remove postinstall script ([999b5d49](http://github.com/the-darc/br-masks/commit/999b5d49))


<a name"0.4.0"></a>
## 0.4.0 (2015-05-15)

#### Features

* **cpf-cnpj:** New mask for cpf/cnpj inputs ([d9651e24](http://github.com/the-darc/br-masks/commit/d9651e24))


<a name"0.3.4"></a>
### 0.3.4 (2015-05-15)


#### Bug Fixes

* **i.e.:** i.e. masks should only works for string values ([c0b4f06f](http://github.com/the-darc/br-masks/commit/c0b4f06f))
* **phone:** phone mask should TRY to work with numbers ([58563318](http://github.com/the-darc/br-masks/commit/58563318))

