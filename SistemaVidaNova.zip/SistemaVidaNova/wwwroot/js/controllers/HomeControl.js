﻿angular.module('app')
.controller('HomeController', ['$scope', function ($scope) {
    
}])
.controller('UserFotoController', ['$scope', function ($scope) {

}]);